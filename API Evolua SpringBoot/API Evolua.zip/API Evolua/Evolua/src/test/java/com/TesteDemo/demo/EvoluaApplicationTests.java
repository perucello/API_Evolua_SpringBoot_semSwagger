package com.TesteDemo.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvoluaApplicationTests {

	@Test
	void contextLoads() {
	}

}
