create database springboot;
use springboot;
select * from produto;
